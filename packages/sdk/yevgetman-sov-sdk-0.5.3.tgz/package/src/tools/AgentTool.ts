// Phase 13.5 — AgentTool. Thin buildTool() wrapper over the SubagentScheduler:
// validates the input, looks up the scheduler from ToolContext, and returns
// a bounded summary plus child session id and trace id. The scheduler owns
// concurrency, lineage, and cancellation; this tool owns the surface the
// model sees.
//
// The `subagent_type` enum is left as `z.string()` here. The registry's
// patchSchemasAgainstAvailable() rewrites it to a closed enum at tool-pool
// assembly time so the model only sees the agents this harness has actually
// loaded — same pattern Phase 12 will adopt for ToolSearchTool's
// `tool_names` enum.

import { z } from 'zod';
import { buildTool } from '../tool/buildTool.js';

const AgentToolInputSchema = z.object({
  subagent_type: z.string().min(1).describe('The name of the loaded sub-agent to delegate to.'),
  prompt: z
    .string()
    .min(1)
    .describe(
      'The task description for the sub-agent. Be specific — the agent runs as a separate session and only receives this prompt.',
    ),
});

export type AgentToolInput = z.infer<typeof AgentToolInputSchema>;

export type AgentToolOutput = {
  childSessionId: string;
  agentName: string;
  resolvedProvider: string;
  resolvedModel: string;
  terminalReason: string;
  iterationsUsed: number;
  toolCallCount: number;
  durationMs: number;
  summary: string;
};

export const AgentTool = buildTool<AgentToolInput, AgentToolOutput>({
  name: 'AgentTool',
  searchHint: 'Delegate a focused task to a specialized sub-agent.',
  description: () =>
    [
      'Delegate a focused task to a specialized sub-agent that runs as its own session with a bounded toolset and budget.',
      'Use sub-agents when the parent task benefits from a fresh context, a constrained read-only exploration, or an independent verification step.',
      'The sub-agent returns a concise summary; full traces live in the trace log, not in this result.',
    ].join(' '),
  inputSchema: AgentToolInputSchema,
  displayInput: (input) => `${input.subagent_type}: ${input.prompt}`,
  isReadOnly: () => false,
  isConcurrencySafe: () => true,
  isDestructive: () => false,
  renderHint: { kind: 'markdown' },
  async call(input, ctx) {
    const scheduler = ctx.subagentScheduler;
    if (!scheduler) {
      throw new Error(
        'AgentTool: no subagent scheduler in ToolContext (harness bootstrap did not wire one)',
      );
    }
    const agents = ctx.agents;
    if (!agents || !agents.byName.has(input.subagent_type)) {
      const available = agents ? [...agents.byName.keys()].sort().join(', ') : '(none loaded)';
      throw new Error(
        `AgentTool: unknown subagent_type '${input.subagent_type}'. Available: ${available}`,
      );
    }
    // Phase 1 T8 — recursion guard via parent's allowedSubagents. When the
    // calling agent (identified by ctx.parentAgentName) declares a non-empty
    // allowedSubagents list, restrict subagent_type to that list. Empty list
    // or absent parentAgentName = unrestricted (top-level harness + parents
    // without policy).
    if (ctx.parentAgentName !== undefined) {
      const parentAgent = agents.byName.get(ctx.parentAgentName);
      if (parentAgent !== undefined && parentAgent.allowedSubagents.length > 0) {
        if (!parentAgent.allowedSubagents.includes(input.subagent_type)) {
          throw new Error(
            `AgentTool: parent agent '${ctx.parentAgentName}' is not allowed to invoke subagent_type '${input.subagent_type}'. Allowed: ${parentAgent.allowedSubagents.join(', ')}`,
          );
        }
      }
    }
    const parentToolPool = ctx.parentToolPool ?? [];
    // Phase 2 T3 — resolve the per-child timeout override from the lane
    // registry when the target agent declares a `role` that maps to a
    // configured lane. Undefined when no role / no lane / no registry —
    // the scheduler falls through to its existing construction-time
    // fallback chain in that case (`opts.perChildTimeoutMs ??
    // agent.maxTurns * DEFAULT_PER_TURN_TIMEOUT_MS`).
    const targetAgent = agents.byName.get(input.subagent_type);
    const laneTimeoutMs =
      targetAgent?.role !== undefined
        ? ctx.laneRegistry?.lookup(targetAgent.role)?.timeoutMs
        : undefined;
    const result = await scheduler.delegate({
      agentName: input.subagent_type,
      prompt: input.prompt,
      parentSessionId: ctx.sessionId,
      ...(ctx.signal !== undefined ? { parentSignal: ctx.signal } : {}),
      parentToolPool,
      parentToolContext: ctx,
      ...(ctx.canUseTool !== undefined ? { canUseTool: ctx.canUseTool } : {}),
      ...(ctx.memoryManager !== undefined ? { memoryManager: ctx.memoryManager } : {}),
      ...(ctx.traceRecorder !== undefined ? { traceRecorder: ctx.traceRecorder } : {}),
      ...(laneTimeoutMs !== undefined ? { perChildTimeoutMsOverride: laneTimeoutMs } : {}),
      // Phase 2 T4 — pass the runtime's per-turn delegation lifecycle
      // recorder so the scheduler fires lifecycle events at start +
      // completion of this delegation. The runtime's closure routes them
      // onto the four delegator_* SSE events when the call belongs to the
      // active delegator's call graph.
      ...(ctx.delegationLifecycleRecorder !== undefined
        ? { delegationLifecycleRecorder: ctx.delegationLifecycleRecorder }
        : {}),
    });
    const nominalSuccess =
      result.terminal.reason === 'completed' || result.terminal.reason === 'max_turns';
    const hasOutput = result.summary.trim().length > 0;
    return {
      data: {
        childSessionId: result.childSessionId,
        agentName: result.agentName,
        resolvedProvider: result.resolvedProvider,
        resolvedModel: result.resolvedModel,
        terminalReason: result.terminal.reason,
        iterationsUsed: result.iterationsUsed,
        toolCallCount: result.toolCallCount,
        durationMs: result.durationMs,
        summary: result.summary,
      },
      observation: {
        status: nominalSuccess && hasOutput ? 'success' : 'error',
        summary: `${result.agentName} → ${result.terminal.reason} (${result.iterationsUsed} turns, ${result.toolCallCount} tool calls)`,
        artifacts: [`session:${result.childSessionId}`],
      },
    };
  },
  renderResult(output) {
    const lines = [
      `<subagent_result name="${output.agentName}" session="${output.childSessionId}" lane="${output.resolvedProvider}/${output.resolvedModel}" turns="${output.iterationsUsed}" tool_calls="${output.toolCallCount}" duration_ms="${output.durationMs}" terminal="${output.terminalReason}">`,
      output.summary,
      '</subagent_result>',
    ];
    const nominalSuccess =
      output.terminalReason === 'completed' || output.terminalReason === 'max_turns';
    const hasOutput = output.summary.trim().length > 0;
    return {
      content: lines.join('\n'),
      isError: !(nominalSuccess && hasOutput),
    };
  },
}) as unknown as import('../tool/types.js').Tool<unknown, unknown>;
